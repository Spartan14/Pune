package WalletBean;
public class WalletBean {
	private float balance;
	private String name;
	private long mobNo,  accNo;
	
	//CONSTRUCTORS STARTS
	public WalletBean() {
		super();
	}
	
	public WalletBean(long accNo, String name, long mobNo, float balance) {
		this.accNo = accNo;
		this.name = name;
		this.mobNo = mobNo;
		this.balance = balance;
	}
	
	//CONSTRUCTORS ENDS
	
	//GETTER & SETTER STARTS

	
	
	
	public long getAccNo()
	{
		return accNo;
	}

	public void setAccNo(long accNo) 
	{
		this.accNo = accNo;
	}
	public float getBalance() 
	{
		return balance;
	}

	public void setBalance(float balance) 
	{
		this.balance = balance;
	}

	public String getName()
	{
		return name;
	}

	public void setName(String name) 
	{
		this.name = name;
	}

	public long getMobNo()
	{
		return mobNo;
	}

	public void setMobNo(long mobNo) 
	{
		this.mobNo = mobNo;
	}

}
