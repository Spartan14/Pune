package Walletdao;

import java.util.HashMap;

import WalletBean.WalletBean;

public class WalletDao {
	//WalletBean beanObj;
	
	HashMap<Long, WalletBean> hm = new HashMap<Long, WalletBean>();
	public float showBalance(long accNo) throws UserException
	{
		float bal=0;
		if(hm().isEmpty()) 
		{									// CHECKING IF HASH MAP IS EMPTY OR NOT
			throw new UserException("Please create an account first.");
		}
		else 
		{
			if(hm().containsKey(accNo))
			{
				bal=hm().get(accNo).getBalance();
			}
			else 
			{
				throw new UserException("No such Account Exist.");
			}
		}
		return bal;
	}
	
	public void addCustomer(WalletBean WalletBeans) {			// Method To Add Customer 
		//this.beanObj = WalletBeans;						// Storing object 
		hm.put(WalletBeans.getAccNo(), WalletBeans);			// Store  in Hash Map 
	}
	public HashMap<Long,WalletBean> hm(){						//  Return Hash Map Object
		return hm;
	}
	public float withDraw(float withdrawAmount,long accNo) throws UserException 	//update withdraw amount
	{
		float bal=0;
		if(hm().isEmpty()) 
		{
			throw new UserException("Please create an account first.");
		}
		else 
		{		
			if(!hm().containsKey(accNo)) 
				{		
					throw new UserException("No such Account Exist.");
					
				}
				else 
				{
					if(withdrawAmount<hm().get(accNo).getBalance())
						{
						float dep =hm().get(accNo).getBalance() - withdrawAmount;			// DECREMENTING WITHDRAW AMOUNT FROM BANK ACCOUNT
						hm().get(accNo).setBalance(dep);
							bal=hm().get(accNo).getBalance();				// GETTING REMAINING BALANCE
						}
					else 
						{
	
							throw new UserException("Can't withdraw money. Account Balance is low.");
						}
				}
		}
		return bal;
	}
	public String transfer(long sourceAccNo,long destAccNo,float transferAmount) throws UserException	//update both source and destination account balance
	{	 String stmt;
		if(hm().isEmpty()) 
		{
			throw new UserException("Please create an account first.");
		}
		else 
		{
			if(hm().containsKey(sourceAccNo)) 
			{					// CHECKING IF SOURCE ACCOUNT EXIST
				if(hm().containsKey(destAccNo))
				{
					if(sourceAccNo!=destAccNo)
					{
					// CHECKING IF DESTINATION ACCOUNT EXIST
						if(hm().get(sourceAccNo).getBalance() > transferAmount) 
							{		// CHECKING IF TRANSFER AMOUNT IS GREATER THAN BALANCE OR NOT
							float transfer = transferAmount;
							hm().get(sourceAccNo).setBalance(hm().get(sourceAccNo).getBalance() - transfer);		// DECREMENTING THE TRANSFER AMOUNT
							hm().get(destAccNo).setBalance(hm().get(destAccNo).getBalance() + transfer);	// ADDING THE TRANSFER AMOUNT
							stmt="Remaining balance in account number "+sourceAccNo+" is: " +hm().get(sourceAccNo).getBalance();
							}
						else 
							{
								throw new UserException("Can't transfer money. Source Account Balance is low.");
							}
					}
					else
						{
							throw new UserException("transfer from same account to same account is invalid");
						}
				}
				else
					{
						throw new UserException("Destination Account Not Exist.");
					}
			}
			else 
				{
					throw new UserException("Source Account Not Exist.");
				}
		}
				
		return stmt;
	}
	public float deposit(long accNo,float bal) throws UserException //update deposit amount 
	{
		if(hm().isEmpty()) 
		{
			throw new UserException("Create Account First");
		}
		else 
		{
			if(hm().containsKey(accNo)) {
				float dep = bal+ hm().get(accNo).getBalance();		// ADDING DEPOSIT AMOUNT TO BANK ACCOUNT
				hm().get(accNo).setBalance(dep);
				bal=hm().get(accNo).getBalance();					// PRINTING THE BANK BALANCE
		}
			else 
			{
				throw new UserException("No such Account exist");
			}
		}
		
		return bal;
	}
}
