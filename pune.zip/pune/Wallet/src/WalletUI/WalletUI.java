package WalletUI;
import java.util.Scanner;

import WalletBean.WalletBean;
import WalletService.WalletService;
import Walletdao.UserException;
public class WalletUI {
	static int i=1000;

	public static void main(String args[]) throws UserException {
		String ch;
		int flag=-1;
		char choice;
		WalletService serviceObj = new WalletService();
		Validation validate = new Validation();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("\n Welcome to our online Wallet Portal\n 1. Create Account \n 2. Show Balance \n 3. Deposit \n 4. Withdraw \n 5. Fund Transfer \n 6. Exit\n");
			System.out.print("Enter your choice : ");
			if(flag>=0)
			{
			sc.nextLine();
			}
			ch= sc.next();
			switch(ch) {
			case "1":
				try
				{

					System.out.print("Enter Name: ");
					String name = validate.nameCheck(sc.next());
					sc.nextLine();
					System.out.print("Enter Mobile No.: ");
					long mobNo = validate.mobCheck(sc.nextLong());
					long accNo = mobNo + i ;
					i=i+1;
					System.out.print("Enter Balance: "); 
					float balance = validate.amountCheck(sc.nextFloat());
					WalletBean bankBeanObjCreateAccountObj = new WalletBean(accNo, name, mobNo, balance);
					serviceObj.bankAccountCreate(bankBeanObjCreateAccountObj);
					System.out.println("Account created with Account Number: " +accNo);
				}
				catch(Exception e)
				{	
					flag=flag+1;
					System.out.println("Invalid Input Try again!!!");
				}
				break;
			case "2":
				try
				{
					System.out.print("Enter Account Number: ");
					long accNo = sc.nextLong();
					float bal=serviceObj.showBalanceSer(accNo);
					System.out.println("Your Account Balance is: " +bal);			//Printing the account balance
				}
				catch(UserException e)
				{
					flag=0;
					System.out.println("Invalid Input Try again!!!");
				}
				catch(Exception e)
				{
					flag=flag+1;
					System.out.println("try again");
				}
				break;
			case "3":
				try
				{
					System.out.print("Enter Account Number: ");
					long accNo = sc.nextLong();
					System.out.print("Enter Deposit Amount: ");
					float depAmount = validate.amountCheck(sc.nextFloat());
					float bal=serviceObj.depositSer(accNo,depAmount);
					System.out.println("Your account balance is: " + bal);
				}
				catch(UserException e)
				{
					flag=0;
					System.out.println("Invalid Input Try again!!!");
				}
				catch(Exception e)
				{	flag=flag+1;
					System.out.println("Invalid Input Try again!!!");
				}
				break;
			case "4":
				try
				{
					System.out.print("Enter Account Number: ");
					long accNo = sc.nextLong();
					System.out.print("Enter Withdraw Amount: ");
					float withdrawAmount = validate.amountCheck(sc.nextFloat());
					float bal=serviceObj.withdrawSer(withdrawAmount, accNo);
					System.out.println("Withdraw successful.");
					System.out.println("Your account balance is: " +bal);
				}
				catch(UserException e)
				{
					flag=0;
					System.out.println("Invalid Input Try again!!!");
				}
				catch(Exception e)
				{	
					flag=flag+1;
					System.out.println("Invalid Input Try again!!!");
				}
				break;
			case "5":
				try
				{
					System.out.println("Enter Source Account Number: ");
					long sourceAccNo= sc.nextLong();
					System.out.println("Enter Destination Account Number: ");
					long destAccNo= validate.mobCheck(sc.nextLong());
					System.out.println("Enter Amount to transfer: ");
					float transferAmount = validate.amountCheck(sc.nextFloat());
					 String stmt=serviceObj.transferSer(sourceAccNo, destAccNo, transferAmount);

				if(stmt!=null)
				{
					System.out.println("Funds Transferred Successfully.");
				System.out.println(stmt);
				}
				}
				catch(UserException e)
				{
					flag=0;
					System.out.println("Invalid Input Try again!!!");
				}
				catch(Exception e)
				{		
					flag=flag+1;
					System.out.println("Invalid Input Try again!!!");
				}
				break;
			case "6":
				System.out.println("Thank You ! for using ");
				System.exit(0);
			default:
				System.out.println("Invalid Input Try Again !!!!!!!!");
			}
			
			System.out.print("Do you want to continue (y/n)...? : ");
			if(flag>=0)
			{
			sc.nextLine();
			}
			choice = sc.next().charAt(0);
			if(choice == 'y' || choice=='Y')
				continue;
			else if(choice=='n'||choice=='N'){
				System.out.println("Thank You !");
				System.exit(0);
			}
			else
			{
				System.out.println("Invalid Input");
			}
		} while(i != 6 );
		sc.close();
	}
}